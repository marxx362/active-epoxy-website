function handleForm(event) {
  event.preventDefault();
  const form = event.target;
  const fields = Array.from(form.querySelectorAll('input, textarea'));
  const values = fields.map((field) => `${field.placeholder}: ${field.value || 'N/A'}`).join('\n');
  const subject = encodeURIComponent('Active Epoxy Co Quote Request');
  const body = encodeURIComponent(values);
  window.location.href = `mailto:?subject=${subject}&body=${body}`;
  return false;
}
